<?php
// Text
$_['text_subject']  = '%s - Notificação de transação';
$_['text_received'] = 'Sua conta na loja %s foi atualizada.';
$_['text_amount']   = 'Valor da transação:';
$_['text_total']    = 'Seu saldo até este momento é:';