<?php
$_['text_title']      = 'Frenet';
$_['text_sucesso']    = 'Reconexão realizada com sucesso!';
$_['text_free']       = '<span style="color:green;font-weight:bold">Grátis</span>';

$_['error_conexao']   = 'Não foi possível estabelecer conexão com os Frenet. Tentando reconectar...';
$_['error_reconexao'] = 'Falha na tentativa de reconectar com os Frenet. O WebService dos Frenet apresenta instabilidade ou está fora do ar.';
