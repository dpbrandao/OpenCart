<?php		
// Text		
$_['text_title']       	=	"Taxa de envio";