<?php
// Text
$_['text_title']       = 'Frete grátis';
$_['text_description'] = 'Frete grátis';