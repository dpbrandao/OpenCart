<?php
// Heading
$_['heading_title'] = 'Escolha uma loja';

// Text
$_['text_default']  = 'Padrão';
$_['text_store']    = 'Escolha a loja que você deseja visitar.';