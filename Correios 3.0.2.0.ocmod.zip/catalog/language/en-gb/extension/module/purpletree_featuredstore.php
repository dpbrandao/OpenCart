<?php
// Heading
$_['heading_title'] = 'Lojas de vendedor em destaque';

// Text
$_['text_tax']      = 'Ex Tax:';