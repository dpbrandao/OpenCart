<?php
// Heading
$_['heading_title'] = 'Últimas Blogs';

$_['text_readmore'] = 'consulte Mais informação';
