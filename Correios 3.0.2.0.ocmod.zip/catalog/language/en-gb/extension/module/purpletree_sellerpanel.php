<?php 		
		
$_['text_selleroption']   	=	"Opções da Vendedora";
$_['text_dashboard']     = 'Resumo';
$_['text_dashboard_icon']     = 'painel de controle';
$_['text_sellerstore']   	=	"Informações da loja";
$_['text_sellerproduct']   	=	"Gerenciar Produtos";
$_['text_sellerprofile']   	=	"Perfil do Vendedor";
$_['text_sellerorder']   	=	"Pedidos";
$_['text_sellercommission']   	=	"Comissão";
$_['text_removeseller']   	=	"Remover como vendedor";
$_['text_becomeseller']   	=	"Torne-se um vendedor";
$_['text_sellerview']   	=	"Ver loja";
$_['text_approval']   	=	"<b> Aguardando aprovação do vendedor </ b>";
$_['text_sellerpayment']   	=	"Pagamentos";
$_['text_sellerreview']   	=	"Meus comentários";
$_['text_sellerenquiry']   	=	"Inquéritos ao Cliente";
$_['text_downloads']   = "Gerenciar Downloads";
$_['text_bulkproductupload']     = "Upload de produtos em massa";
$_['text_shipping']              = "Taxas de envio";

$_['text_subscription']              = "Plano de Assinatura";
$_['text_subscriptions']              = "Fatura de Subscrição";
$_['text_blog_post']             	     = 'Blog';
$_['text_blog_comment']              	 = 'Comentários do Blog';
$_['text_commissioninvoice']   = 'Faturas da Comissão';
?>		