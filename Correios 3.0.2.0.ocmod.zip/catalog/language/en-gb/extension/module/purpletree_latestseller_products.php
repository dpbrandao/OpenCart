<?php
// Heading
$_['heading_title'] = 'Últimos Produtos do Vendedor';

// Text
$_['text_tax']      = 'Ex Tax:';