<?php
// Heading
$_['heading_title'] = 'Produtos em destaque do vendedor';

// Text
$_['text_tax']      = 'Ex Tax:';