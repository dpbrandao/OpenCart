<?php		
// Heading		
$_['heading_title']         	=	"Visualização da loja";
		
//text		
		
$_['text_dashboard']			=	"Dashboard";
$_['text_storeview']			=	"Visualização da loja";
$_['text_returnpolicy']			=	"Política de Devolução";
$_['text_shippingpolicy']			=	"Política de Envio";
$_['text_empty']        	=	" Não há produtos para listar na loja deste vendedor ";
$_['text_error']        	=	" Loja não encontrada ";
$_['text_quantity']     	=	"Qtd";
$_['text_manufacturer'] 	=	"Marca:";
$_['text_model']        	=	"Código do produto:";
$_['text_points']       	=	"Pontos de recompensa:";
$_['text_price']        	=	"Preço:";
$_['text_tax']          	=	"Ex Tax:";
$_['text_compare']      	=	"Comparação do produto (% s)";
$_['text_sort']         	=	"Ordenar Por:";
$_['text_default']      	=	"Padrão";
$_['text_name_asc']     	=	"Nome: A - Z";
$_['text_name_desc']    	=	"Nome (Z-A)";
$_['text_price_asc']    	=	"Preço (baixo e alto)";
$_['text_price_desc']   	=	"Preço (alto e baixo)";
$_['text_rating_asc']   	=	"Classificação (menor)";
$_['text_rating_desc']  	=	"Avaliação (Maior)";
$_['text_model_asc']    	=	"Modelo (A - Z)";
$_['text_model_desc']   	=	"Modelo (Z-A)";
$_['text_limit']        	=	"Mostrar:";
$_['text_aboutstore']        	=	"Sobre a Loja";
$_['text_sellerreview']        	=	"Avaliações";
$_['text_sellercontact']			=	"Contatar vendedor";
$_['text_products_categories'] 	=	"Categorias";
$_['text_remove_account_success'] 	=	"Sua conta foi removida com sucesso.";
