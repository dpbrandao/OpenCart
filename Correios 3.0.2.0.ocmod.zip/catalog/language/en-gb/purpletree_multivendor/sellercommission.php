<?php 		
$_['heading_title']			=	"Comissão";
		
//text		
$_['text_commission']			=	"Comissão";
$_['text_total_sale']		=	"Venda Total";
$_['text_total_commission']			=	"Comissão Total";
$_['text_recvd_amt']			=	"Montante total recebido";
$_['text_pending_amt']			=	"Montante total pendente";
$_['text_order_id']			=	"Id Pedido";
$_['text_product_id']			=	"Nome do Produto";
$_['text_product_price']			=	"Preço do produto";
$_['text_status']			=	"Estado";
$_['text_created_at']			=	"data criada";
$_['text_empty']			=	"Você não tem nenhuma comissão!";
$_['entry_date_from']          	=	"Data de:";
$_['entry_date_to']          	=	"Data para";
		
$_['button_filter'] 	=	"Filtro";
?>		