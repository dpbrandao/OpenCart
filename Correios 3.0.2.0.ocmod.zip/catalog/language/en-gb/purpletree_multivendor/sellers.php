<?php		
// Text		
$_['text_heading'] 			=	"Vendedores";
$_['text_refine']       	=	"Buscar";
$_['text_product']      	=	"Produtos";
$_['text_sellercontact']	=	"Contatar vendedor";
$_['text_empty']        	=	"Não há vendedores para a listagem.";
$_['text_sort']         	=	"Ordenar Por:";
$_['text_name_asc']     	=	"Nome: A - Z";
$_['text_name_desc']    	=	"Nome (Z-A)";
$_['text_limit']        	=	"Mostrar:";