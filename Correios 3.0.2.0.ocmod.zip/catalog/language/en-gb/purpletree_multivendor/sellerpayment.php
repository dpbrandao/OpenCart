<?php 		
$_['heading_title']			=	"Pagamentos";
		
//text		
$_['text_payment']			=	"Pagamentos";
$_['text_trnasaction']			=	"Id da Transacton";
$_['text_amount']			=	"Quantia";
$_['text_payment_mode']			=	"Modo de pagamento:";
$_['text_status']			=	"Estado";
$_['text_created_at']			=	"data criada";
$_['text_empty']			=	"Você não tem nenhum pagamento!";
		
$_['entry_date_from']          	=	"Data de:";
$_['entry_date_to']          	=	"Data para";
		
$_['button_filter'] 	=	"Filtro";
?>	