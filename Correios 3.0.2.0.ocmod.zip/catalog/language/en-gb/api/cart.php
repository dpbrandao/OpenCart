<?php
// Text
$_['text_success']     = 'O carrinho de compras foi modificado com sucesso.';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para acessar a API.';
$_['error_stock']      = 'Os produtos marcados com *** não estão disponíveis na quantia solicitada ou não encontram-se em estoque.';
$_['error_minimum']    = 'A quantidade mínima para %s é %s.';
$_['error_store']      = 'O produto não pode ser comprado na loja selecionada.';
$_['error_required']   = 'O campo %s é obrigatório.';