<?php
// Heading
$_['heading_title']    = 'Código de rastreamento';

// Text
$_['text_account']     = 'Minha conta';
$_['text_description'] = 'Para ter certeza que suas indicações vão ser registradas corretamente, gere os links para nossos produtos através do formulário abaixo:';

// Entry
$_['entry_code']       = 'Código de rastreamento';
$_['entry_generator']  = 'Pesquisar produto';
$_['entry_link']       = 'Link para divulgação';

// Help
$_['help_generator']   = 'Digite o nome de um produto para gerar o link para divulgação.';