<?php
// Heading
$_['heading_title']    = 'Informativo de novidades e promoções.';

// Text
$_['text_account']     = 'Minha conta';
$_['text_newsletter']  = 'Informativo';
$_['text_success']     = 'A sua assinatura foi atualizada.';

// Entry
$_['entry_newsletter'] = 'Assinado:';